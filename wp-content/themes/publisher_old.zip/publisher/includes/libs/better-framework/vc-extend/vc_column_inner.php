<?php
global $_vc_column_inner_template_file, $_bf_vc_column_inner_atts;


$_bf_vc_column_inner_atts = $atts;
if ( $_vc_column_inner_template_file ) {
	include $_vc_column_inner_template_file;
}

