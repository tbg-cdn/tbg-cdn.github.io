<?php
include BF_PATH . 'core/field-generator/fields/term_select.php';
?>

<input type="hidden"
       name="<?php echo esc_attr( $options['input_name'] ) ?>"
       value="<?php echo esc_attr( $options['value'] ) ?>"
       class="bf-vc-term-select-value <?php echo isset( $options['input_class'] ) ? esc_attr( $options['input_class'] ) : ''; ?>"
>
