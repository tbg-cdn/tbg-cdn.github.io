<?php
/**
 * header.php
 *---------------------------
 * The template for displaying the header.
 *
 */

// Prints all codes before <body> tag.
// Location: "views/general/header/_common.php"
publisher_get_view( 'header', '_common', 'general' );

// Activates duplicate posts removal temporarily for not counting posts inside mega menu
publisher_set_global( 'disable-duplicate-posts', TRUE );

?>
	<div class="main-wrap">
<?php

// Prints header code base the style was selected in panel.
// Location: "views/general/header/header-*.php"
publisher_get_view( 'header', 'header-' . publisher_get_header_style() );

// After header Ad
publisher_show_ad_location( 'header_after', array( 'container-class' => 'adloc-after-header' ) );

?>
	<div class="content-wrap">
<main <?php publisher_attr( 'content', '' ); ?>>
<?php

// Deactivates duplicate posts removal temporarily
publisher_unset_global( 'disable-duplicate-posts' );
