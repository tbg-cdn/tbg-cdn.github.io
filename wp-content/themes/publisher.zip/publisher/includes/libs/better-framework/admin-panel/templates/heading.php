<div class="bf-section-container bf-clearfix"
     data-param-name="<?php echo esc_attr( $options['id'] ) ?>"
     <?php if ( $_settings = array_intersect_key( $options, BF_Admin_Fields::$public_options ) ) { ?>data-param-settings="<?php echo esc_attr( json_encode( $_settings ) ) ?>" <?php  } ?>>

	<div class="bf-section-heading bf-clearfix">
		<div class="bf-section-heading-title bf-clearfix">
			<h3><?php echo esc_html( $options['name'] ); ?></h3>
		</div>
		<?php if ( ! empty( $options['desc'] ) ) { ?>
			<div
				class="bf-section-heading-desc bf-clearfix"><?php echo wp_kses( $options['desc'], bf_trans_allowed_html() ); ?></div>
		<?php } ?>
	</div>
</div>