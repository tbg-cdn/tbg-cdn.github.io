<div class="bf-section-container bf-clearfix"
     data-param-name="<?php echo esc_attr( $options['id'] ) ?>"
     <?php if ( $_settings = array_intersect_key( $options, BF_Admin_Fields::$public_options ) ) { ?>data-param-settings="<?php echo esc_attr( json_encode( $_settings ) ) ?>" <?php  } ?>>

<div class="bf-section-hr bf-clearfix">
		<?php echo $input; // escaped before in generating ?>
	</div>
</div>