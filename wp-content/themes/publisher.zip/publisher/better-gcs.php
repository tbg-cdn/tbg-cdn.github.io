<?php
/**
 * better-gcs.php
 *---------------------------
 * "Better Google Custom Search" plugin template.
 *
 */

get_header();


// Generate layout settings
$layout_setting = publisher_get_page_layout_setting();

?>
	<div class="container <?php echo $layout_setting['container']; ?>">
		<div class="row main-section">
			<?php

			foreach ( $layout_setting['columns'] as $column ) {

				if ( $column['id'] == 'content' ) {
					?>
					<div class="<?php echo $column['class']; ?>">
						<?php

						// Pre title
						$pre_title = sprintf(
							publisher_translation_get( 'archive_search_title' ),
							'<i>' . get_search_query() . '</i>',
							''
						);

						?>
						<section class="archive-title search-title search-bgcs-title">
							<h1 class="section-heading"><span
									class="h-text"><?php echo $pre_title; // escaped before ?></span></h1>
						</section>
						<?php

						Better_GCS_Search_Box();

						?>
					</div><!-- .content-column -->
					<?php
				} else {
					?>
					<div class="<?php echo $column['class']; ?>">
						<?php get_sidebar( $column['id'] ); ?>
					</div><!-- .<?php echo $column['id']; ?>-sidebar-column -->
					<?php
				}
			}

			?>
		</div><!-- .main-section -->
	</div>

<?php

get_footer();