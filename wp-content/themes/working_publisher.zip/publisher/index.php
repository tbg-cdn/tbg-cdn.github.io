<?php
/**
 * index.php
 *---------------------------
 *
 * This file uses archive.php
 *
 * @package Publisher
 */

get_template_part( 'archive' );
