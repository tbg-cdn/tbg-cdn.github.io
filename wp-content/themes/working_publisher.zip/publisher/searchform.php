<?php
/**
 * searchform.php
 *---------------------------
 * The template for displaying search form.
 *
 */

// Location: "views/general/wp/searchform.php"
publisher_get_view( 'wp', 'searchform' );
