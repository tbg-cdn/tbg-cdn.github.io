<?php
die;