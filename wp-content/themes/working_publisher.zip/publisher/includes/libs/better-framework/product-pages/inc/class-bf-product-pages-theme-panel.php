<?php

class BF_Product_Pages_Theme_Panel extends BF_Product_Item {

	public function render_content( $item_data ) {
	}

	public function item_data() {
	}
}